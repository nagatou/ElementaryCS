# Cyclic towers of Hanoi problem
# Mode:: Python3
import os
import random


os.system('clear')

def hanoi (n,source,dest,via,result):
    if n == 1:
        result.append([source,dest])
        return
    hanoi(n-1,source,via,dest,result)
    hanoi(1,source,dest,via,result)
    hanoi(n-1,via,dest,source,result)


class hanoi_random:
    def __init__(self,n):
        self.n = n
        l = list(range(self.n))
        l_rev = sorted(l, reverse=True)
        self.stick = [l_rev,[-1],[-1]]
        self.turn = 0
    def move(self):
        if self.turn != 0 and len(self.stick[1]) == self.n:
            print(str(self.turn)+'回の操作で達成されました')
            return
        else:
            rand_source, rand_dest = random.sample(range(3),2)
            if len(self.stick[rand_source]) > 0:
                if self.stick[rand_dest][0] == -1 and self.stick[rand_source][len(self.stick[rand_source])-1] != -1:
                    self.turn += 1
                    self.stick[rand_dest][0] = self.stick[rand_source][len(self.stick[rand_source])-1]
                    del self.stick[rand_source][len(self.stick[rand_source])-1]
                    print('from' + str(rand_source) + 'to' + str(rand_dest))
                elif self.stick[rand_source][0] != -1 and self.stick[rand_source][len(self.stick[rand_source])-1] < self.stick[rand_dest][len(self.stick[rand_dest])-1]:
                    self.turn += 1
                    self.stick[rand_dest].append(self.stick[rand_source][len(self.stick[rand_source])-1])
                    del self.stick[rand_source][len(self.stick[rand_source])-1]
                    print('from' + str(rand_source) + 'to' + str(rand_dest))
                if len(self.stick[rand_source]) == 0:
                        self.stick[rand_source].append(-1)
            self.move()

while True:
    k = input('最短経路で求めたければ"s"を、ランダムにときたければ"r"を入力してエンターを押してください')
    if k == 's' or k == 'r':
        break

n = int(input('n?'))
if k == 's':
    result=[]   # an element of result has to be a list whose length is fixed to 2.
    hanoi(n,1,2,3,result)
    for step in range(len(result)):
        print("From {0} to {1}.".format(result[step][0],result[step][1]))
else:
    hanoi_random(n).move()




