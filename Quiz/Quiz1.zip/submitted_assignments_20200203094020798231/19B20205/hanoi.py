def hanoi(n,s,g,v,result):
    if n==1:
        return result + [[s,g]]
    else:
        return hanoi(n-1,s,v,g,result)+[[s,g]]+hanoi(n-1,v,g,s,result)

n=int(input("enter the number of discs(>0)"))
moves=[]
for move in hanoi(n,1,2,3,moves):
    print("From ",move[0]," to ",move[1],".",sep='')
