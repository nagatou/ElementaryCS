import os
N = int(input("How many disks?"))

def hanoi(n,source,dest,via):
    
    if n == 1:
        print(f"{n} disk from {source} to {dest}")
        return
   
    hanoi(n-1, source, via, dest)

    print(f"{n} disk from {source} to {dest}")
 
    hanoi(n-1, via, dest, source)

hanoi(N, "柱１", "柱２", "柱３")







