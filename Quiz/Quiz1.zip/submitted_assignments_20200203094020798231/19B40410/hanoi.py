## 19B40410
# Cyclic towers of Hanoi problem
# Mode:: Python3
import os

def hanoi(n,source,dest,via):
    if n==1:                                            #1枚を動かすとき
        print("From {0} to {1}.".format(source,dest))   #それを表示
    else:                             #2枚以上を動かすとき
        hanoi(n-1,source,via,dest)    #一番下の1枚以外を目標と違う柱へ
        hanoi(1,source,dest,via)      #一番下の1枚を目標の柱へ
        hanoi(n-1,via,dest,source)    #先ほど動かしたn-1枚を目標の柱へ

### Test Harness
os.system('clear')
m = int(input("enter the number of discs (>0)? "))
hanoi(m,1,2,3)
