import os

def hanoi(n,source,dest,via):
    if n==1:
        print(f"from {source} to {dest}")
        return
    else:
        hanoi(n-1,source,via,dest)
        hanoi(1,source,dest,via)
        hanoi(n-1,via,dest,source)

os.system('clear')
n = int(input("enter the number of discs (>0)? "))
hanoi(n,"1","2","3")