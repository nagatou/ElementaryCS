# Cyclic towers of Hanoi problem
# Mode:: Python3
import os

def hanoi(n,fr,to,via):
    if n == 1:
        print("Move disc 1 from {} to {}".format(fr,to))
    else:
        hanoi(n-1,fr,via,to)
        print("Move desc {} from {} to {}".format(n,fr,to))
        hanoi(n-1,via,to,fr)

### Test Harness
os.system('cls')
m = int(input("enter the number of discs (>0)? "))
  # an element of result has to be a list whose length is fixed to 2.
hanoi(m,1,2,3,)
