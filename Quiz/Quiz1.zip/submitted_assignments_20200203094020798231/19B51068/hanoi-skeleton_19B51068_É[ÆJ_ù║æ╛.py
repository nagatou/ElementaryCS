# Cyclic towers of Hanoi problem
# Mode:: Python3
import os

def hanoi (n,source,dest,via,result):

    if n > 0:
        hanoi(n-1,source,via,dest,result)
        result[dest].insert(0,result[source].pop(0))
        print((result['left'],result['center'],result['right']))
        hanoi(n-1,via,dest,source,result)

if __name__== '__main__':
    n = int(input())
    result = {'left': [i for i in range(1, n+1)], 'center':[],'right':[]}
    print((result['left'],result['center'],result['right']))
    hanoi(n,'left','center','right',result)
### Test Harness
