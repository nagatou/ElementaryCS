
def hanoi (n,source,dest,via,result):
    if n==1:
        return result.append([source,dest])
    else:
        hanoi(n-1,source,via,dest,result)
        hanoi(1,source,dest,via,result)
        return hanoi(n-1,via,dest,source,result)

m = int(input("enter the number of discs (>0)? "))
result=[]
hanoi(m,1,2,3,result)
for step in range(len(result)):
  print("From {0} to {1}.".format(result[step][0],result[step][1]))