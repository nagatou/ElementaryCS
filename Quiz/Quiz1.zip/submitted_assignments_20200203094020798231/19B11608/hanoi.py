def hanoi(n,x,y,z):
    if n==1:
        print("From {} to {}".format(x,y))

    else:
        hanoi(n-1,x,z,y)
        print("From {} to {}".format(x,y))
        hanoi(n-1,z,y,x)

m = int(input("enter the number of discs (>0)? "))
hanoi(m,"1","2","3")
