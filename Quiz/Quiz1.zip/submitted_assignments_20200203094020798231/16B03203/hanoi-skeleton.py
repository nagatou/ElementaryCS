# Cyclic towers of Hanoi problem
# Mode:: Python3
##棒が1、2、3、とあったときにn個の円盤を
##棒１から棒２へ全て移動させるためのハノイの塔のプロセス

import os

def hanoi (n,source,dest,via,result):
    from_to=[None]*2
    if(n==1):
        from_to[0]=source
        from_to[1]=dest
        result.append(from_to)
    else:
        hanoi(n-1,source,via,dest,result)
        from_to[0]=source
        from_to[1]=dest
        result.append(from_to)
        hanoi (n-1,via,dest,source,result)
os.system("clear")
m = int(input("enter the number of discs (>0)? "))
result=[]
hanoi(m,1,2,3,result)
for step in range(len(result)):
  print("From {0} to {1}".format(result[step][0],result[step][1]))


