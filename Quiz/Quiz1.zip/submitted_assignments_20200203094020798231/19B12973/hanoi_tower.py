# Cyclic towers of Hanoi problem
# Mode:: Python3
import os
#n枚のディスクをsourceからviaを経由してdestに移す。
def hanoi(n,source,dest,via,result):

    if n ==1 :
        #1枚の円盤なら移して返す
        result.append([source,dest])
        disk.append([n])
        return 
    else:
        hanoi(n-1,source,via,dest,result)
        result.append([source,dest])
        disk.append([n])
        hanoi(n-1,via,dest,source,result)
 
    # ここか

### Test Harness
os.system('clear')
m = int(input("enter the number of discs (>0)? "))
result=[]   # an element of result has to be a list whose length is fixed to 2.
disk=[] 
hanoi(m,1,2,3,result)
for step in range(len(result)):
  print("Move disk {0} from {1} to {2}.".format(disk[step][0],result[step][0],result[step][1]))
  