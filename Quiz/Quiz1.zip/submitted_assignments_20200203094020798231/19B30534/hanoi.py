n = int(input("how many disc?>> "))

def hanoi(n, s, g, via, result):
    if 1 == n:
        result.append([s, g])
    else:
        hanoi(n-1, s, via, g, result)
        result.append([s, g])
        hanoi(n-1, via, g, s, result)
    return result

ans = hanoi(n, "1", "2", "3", [])
for i in range(len(ans)):
    print("From", ans[i][0], "To", ans[i][1])
print("setp =", len(ans))