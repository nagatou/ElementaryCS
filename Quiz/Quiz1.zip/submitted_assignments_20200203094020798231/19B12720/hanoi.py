# Cyclic towers of Hanoi problem
# Mode:: Python3
import os

def hanoi (n,source,dest,via,result):
    if n == 1:
        result[0].append(source)
        result[1].append(dest)

    else:
        result = hanoi(n-1,source,via,dest,result)
        result = hanoi(1,source,dest,via,result)
        result = hanoi(n-1,via,dest,source,result)

    return(result)

### Test Harness
os.system('clear')
m = int(input("enter the number of discs (>0)? "))
result=[[],[]]   # an element of result has to be a list whose length is fixed to 2.
hanoi(m,1,2,3,result)
for step in range(len(result[0])):
  print("From {0} to {1}.".format(result[0][step],result[1][step]))

print ("かかった移動 = {0}".format(step+1))



#print(result)
#print(len(result))
#print(len(result[0]))
#print(len(result[1]))


# 上から n − 1 個目までの円盤を何らかの方法でA(source)からC(via)に移動する。
#残った1枚をA(source)からB(dest)に移動する。
#C(via)にある円盤を何らかの方法でC(via)からB(dest)に移動する。
#(wikipediaより)
