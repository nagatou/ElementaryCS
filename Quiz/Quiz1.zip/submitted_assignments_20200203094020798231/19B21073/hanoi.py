# Cyclic towers of Hanoi problem
# Mode:: Python3
import os

def hanoi (n,source,dest,via):
  if n == 1:
        print("Move {0} disk from {1} to {2}.".format(n, source, dest))
        return
  hanoi(n-1,source,via,dest)
  print("Move {0} disk from {1} to {2}.".format(n, source, dest))
  hanoi(n-1,via,dest,source)

### Test Harness
os.system('clear')
m = int(input("enter the number of discs (>0)? "))
hanoi(m,1,2,3)
