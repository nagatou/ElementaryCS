# Several sorting algorithms
#Mode:: Python3

import os, time, random

def swap (x,y):
  return(y,x)
def comp (x,y):
  if (x < y):
    return(True)
  else:
    return(False)

def bubble_sort(numbers,cmp_fun):
  for i in range(0,len(numbers)):
    for j in range(len(numbers)-1,i,-1):
      if cmp_fun(numbers[j],numbers[j-1]):
        numbers[j],numbers[j-1] = swap(numbers[j],numbers[j-1])
  return(numbers)  

def insertion_sort(numbers,cmp_fun):
  for i in range(1,len(numbers)):
    j=i
    while (j>0) and cmp_fun(numbers[j],numbers[j-1]):
      numbers[j],numbers[j-1] = swap(numbers[j],numbers[j-1])
      j=j-1
  return(numbers)

def quick_sort(numbers,cmp_fun):
  if numbers[1:]==numbers[:-1]:
    numbers=numbers
  else:
    if cmp_fun(numbers[0],numbers[1]):
      pivot=numbers[1]
    else:
      pivot=numbers[0]
    i=0
    j=len(numbers)-1
    k=len(numbers)-1
    while j-i>0:
      if numbers[i]<pivot:
        i+=1
      elif numbers[j]>=pivot:
        j-=1
      else:
        numbers[i],numbers[j]=swap(numbers[i],numbers[j])
    while k-j>0:
      if numbers[j]==pivot:
        j+=1
      elif numbers[k]!=pivot:
        k-=1
      else:
        numbers[j],numbers[k]=swap(numbers[j],numbers[k])
    numbers=quick_sort(numbers[:i],cmp_fun)+[pivot]*(j-i)+quick_sort(numbers[j:],cmp_fun)
  return(numbers)
  ### ?????
#
## Test Harness
#
size = int(input("the size of numbers (>2) "))
numbers = [0]*size
for i in range(0,len(numbers)):
  random.seed(None,2)
  numbers[i]=random.randint(0,size)
start_time = time.time()
print("{0},\n processing time(quick sort): {1} sec\n".format(quick_sort(numbers[:],comp),time.time()-start_time))
start_time = time.time()
print("{0},\n processing time(insertion sort): {1} sec\n".format(insertion_sort(numbers[:],comp),time.time()-start_time))
start_time = time.time()
print("{0},\n processing time(bubble sort): {1} sec\n".format(bubble_sort(numbers[:],comp),time.time()-start_time))
print("oridin:\n{0}".format(numbers))
