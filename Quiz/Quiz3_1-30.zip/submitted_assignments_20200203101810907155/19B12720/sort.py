# Several sorting algorithms
#Mode:: Python3

import os, time, random

def swap (x,y):
  return(y,x)
def comp (x,y):
  if (x < y):
    return(True)
  else:
    return(False)

def bubble_sort(numbers,cmp_fun):
  for i in range(0,len(numbers)):
    for j in range(len(numbers)-1,i,-1):
      if cmp_fun(numbers[j],numbers[j-1]):
        numbers[j],numbers[j-1] = swap(numbers[j],numbers[j-1])
  return(numbers)  

def insertion_sort(numbers,cmp_fun):
  for i in range(1,len(numbers)):
    j=i
    while (j>0) and cmp_fun(numbers[j],numbers[j-1]):
      numbers[j],numbers[j-1] = swap(numbers[j],numbers[j-1])
      j=j-1
  return(numbers)


def quick_sort(numbers,cmp_fun,low,high):
  ## numbers:配列　low:最初の配列番号 high:最後の配列番号
  # pivot
  if(low >= high):
    return(numbers)
  
  pivot = low + 1
  # 異なる２つの数字を探す
  while(pivot < high  and numbers[low]==numbers[pivot]):
    pivot += 1
  # 比較して大きい(小さい)方をpivotに入れる
  if(cmp_fun(numbers[pivot],numbers[low])):
    pivot = low
  elif(numbers[pivot]==numbers[low]):
    return(numbers)
  pivot = numbers[pivot]

  # partition
  i = low
  j = high
  while(i<=j):
    while(i<high and cmp_fun(numbers[i],pivot)):
      # pivotより小さい数の番号を探す
      i+=1
      #print("i= "+str(i))
    while(j>low and cmp_fun(pivot,numbers[j]) or pivot==numbers[j]):
      # pivot以上の数の番号を探す
      j-=1
      #print("j= "+str(j))
    if(i>=j):
      break
    numbers[i],numbers[j] = swap(numbers[i],numbers[j])
    # 入れ替える
    #print("swap{0},{1}".format(i,j))

  #print("pivor="+str(pivot))
  #print(i)
  #print(j)
  #print("low="+str(low))
  #print("high="+str(high))
  #print(numbers)
  quick_sort(numbers,cmp_fun,low,i-1)
  quick_sort(numbers,cmp_fun,i,high)
  return(numbers)


#
## Test Harness
#
size = int(input("the size of numbers (>2) "))
numbers = [0]*size
for i in range(0,len(numbers)):
  random.seed(None,2)
  numbers[i]=random.randint(0,size)

start_time = time.time()
print("{0},\n processing time(quick sort): {1} sec\n".format(quick_sort(numbers[:],comp,0,len(numbers)-1),time.time()-start_time))
start_time = time.time()
print("{0},\n processing time(insertion sort): {1} sec\n".format(insertion_sort(numbers[:],comp),time.time()-start_time))
start_time = time.time()
print("{0},\n processing time(bubble sort): {1} sec\n".format(bubble_sort(numbers[:],comp),time.time()-start_time))
print("oridin:\n{0}".format(numbers))
