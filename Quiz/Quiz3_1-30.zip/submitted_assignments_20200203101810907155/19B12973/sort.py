#qiuick_sortのオーダーは nlog(n)です。

import  time, random

def swap (x,y):
  return(y,x)
def comp (x,y):
  if (x < y):
    return(True)
  else:
    return(False)

def bubble_sort(numbers,cmp_fun):
  for i in range(0,len(numbers)):
    for j in range(len(numbers)-1,i,-1):
      if cmp_fun(numbers[j],numbers[j-1]):
        numbers[j],numbers[j-1] = swap(numbers[j],numbers[j-1])
  return(numbers)  
def insertion_sort(numbers,cmp_fun):
  for i in range(1,len(numbers)):
    j=i
    while (j>0) and cmp_fun(numbers[j],numbers[j-1]):
      numbers[j],numbers[j-1] = swap(numbers[j],numbers[j-1])
      j=j-1
  return(numbers)
def median(x, y, z):
    if x < y:
        return (y if y < z else z) if x < z else x
    else:
        return (x if x < z else z) if y < z else y 
  
def quick_sort(numbers,cmp_fun):
    low = []
    high = []
    if len(numbers) <= 1:
        return numbers
    x = len(numbers)
    pivot = median(numbers[0],numbers[x//2],numbers[x-1]) 
    pivot_count = 0
    for a in range(len(numbers)):
        if pivot > numbers[a]:
            low.append(numbers[a])
        elif pivot < numbers[a]:
            high.append(numbers[a])
        else:
            pivot_count += 1
            
    low = quick_sort(low,cmp_fun)
    high = quick_sort(high,cmp_fun)
    return low + [pivot] * pivot_count + high
 
    print(quick_sort(numbers,cmp_fun))
    

  


#
## Test Harness
#
size = int(input("the size of numbers (>2) "))
numbers = [0]*size
for i in range(0,len(numbers)):
  random.seed(None,2)
  numbers[i]=random.randint(0,size)
start_time = time.time()
print("{0},\n processing time(quick sort): {1} sec\n".format(quick_sort(numbers[:],comp),time.time()-start_time))
start_time = time.time()
print("{0},\n processing time(insertion sort): {1} sec\n".format(insertion_sort(numbers[:],comp),time.time()-start_time))
start_time = time.time()
print("{0},\n processing time(bubble sort): {1} sec\n".format(bubble_sort(numbers[:],comp),time.time()-start_time))
print("oridin:\n{0}".format(numbers))