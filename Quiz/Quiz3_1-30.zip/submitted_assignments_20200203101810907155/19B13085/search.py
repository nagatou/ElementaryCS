import time, random

def linear_search(numbers, target):
  i = 0
  while numbers[i] <= target:
    if numbers[i] == target:
      return i
    i += 1
  return -1


def binary_search(numbers, target):
  s = 0
  i = len(numbers)
  
  while numbers != []:
    i //= 2
    if numbers[i] == target:
      return s + i
    elif len(numbers) == 1: 
      break
    elif numbers[i] > target:
      numbers = numbers[:i]
    elif numbers[i] < target:
      s += i+1
      numbers = numbers[i+1:]
      i = len(numbers)
  
  return -1
    

size = int(input("the size of numbers (>2) "))
target = int(input("the target of number "))
numbers = [0]*size
for i in range(0, len(numbers)):
  random.seed(None, 2)
  numbers[i] = random.randint(0, size)

numbers.sort()


start_time = time.time()
print("index of target is {0},\n processing time(linear search): {1} sec\n".format(linear_search(numbers[:], target), time.time()-start_time))
start_time = time.time()
print("index of target is {0},\n processing time(binary search): {1} sec\n".format(binary_search(numbers[:], target), time.time()-start_time))
print("oridin:\n{0}".format(numbers))
