#テストコードフラグ
#Trueにすると最後にテストコードが走る
FAST_FUNC_TEST = False
NORMAL_FUNC_TEST = False

#power
import os, time, sys
sys.setrecursionlimit(2000)

def power(b,n):
  if (n==0):
    return(1)
  else:
    return(b * power(b, n-1))

def power_cps(b,n):
  def power_cps1(b,n,product):
    if (n==0):
      return(product)
    else:
      return(power_cps1(b,n-1,(b*product)))
  return(power_cps1(b,n,1))

def power_iter(b,n):
  product=1
  for _ in range(n):
    product *= b
  return (product)

def square(x):
  return(x*x)
def is_even(n):
  if (n%2==0):
    return(True)
  else:
    return(False)
def fast_power(b,n):
  if (n==1):
    return(b) 
  else:
    if (is_even(n)):
      return(square(fast_power(b,n/2)))
    else:
      return((b*fast_power(b,n-1)))

def fast_power_cps(b,n):
  def fast_power_cps1(b,n,product):
    if (n==0):
      return(product) 
    else:
      if (is_even(n)):
        return(fast_power_cps1(square(b),n/2,product))
      else:
        return((fast_power_cps1(b,n-1,product*b)))
  return(fast_power_cps1(b,n,1))

def fast_power_iter(b,n):
  product=1
  while n > 0:
    if (is_even(n)):
      b *= b
      n /= 2
    else:
      n -= 1
      product *= b

  return(product) 

# Test Harness
os.system('clear')
x = int(input("x?; (x^y)"))
y = int(input("y? "))
start_time = time.time()
print("x to the power of y is {0},\n processing time(Fast_Iter): {1:10f} sec\n".format(fast_power_iter(x,y),time.time()-start_time))
start_time = time.time()
print("x to the power of y is {0},\n processing time(Fast CPS): {1:10f} sec\n".format(fast_power_cps(x,y),time.time()-start_time))
start_time = time.time()
print("x to the power of y is {0},\n processing time(Fast): {1:10f} sec\n".format(fast_power(x,y),time.time()-start_time))
start_time = time.time()
print("x to the power of y is {0},\n processing time(Iterate): {1:10f} sec\n".format(power_iter(x,y),time.time()-start_time))
start_time = time.time()
print("x to the power of y is {0},\n processing time(CPS): {1:10f} sec\n".format(power_cps(x,y),time.time()-start_time))
start_time = time.time()
print("x to the power of y is {0},\n processing time(Naive): {1:10f} sec\n".format(power(x,y),time.time()-start_time))

#以下テストコード
def test_func(func, max_b=100, max_n=100):
  """
  関数が正しい冪乗を返すかを確かめる．　　
  基底bと指数nの全ての組み合わせについてテストを行う．

  Parameters
  ----------
  func:　正しい冪乗を返すかを確かめる対象の関数  
  max_b: 最大の基底  
  max_n: 最大の指数  
  """
  ok = True
  for b in range(max_b):
    for n in range(max_n):
      k = b ** n
      if func(b, n) != k:
        print('Error', b, n)
        ok = False
  if ok:
    print(func.__name__ + 'is valid (0 <= b < {}, 0 <= n < {})'.format(max_b, max_n))

if FAST_FUNC_TEST:
  test_func(fast_power_iter)

if NORMAL_FUNC_TEST:
  test_func(power_iter)