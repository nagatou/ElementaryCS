#quick sort の　平均計算量 O(NlogN)
#bubble sort の　平均計算量 O(N^2)
#insertion sort の　平均計算量 O(N^2)

#テストコードを実行するか
TEST = False
#タイム計測コードを実行するか
TIME_TEST = True
#再帰quick sort と非再起quick sortの計算時間の比較をするか
TEST_COMP_QUICK = False



import os, time, random
import sys

def swap (x,y):
  return(y,x)
def comp (x,y):
  if (x < y):
    return(True)
  else:
    return(False)

def bubble_sort(numbers,cmp_fun):
  for i in range(0,len(numbers)):
    for j in range(len(numbers)-1,i,-1):
      if cmp_fun(numbers[j],numbers[j-1]):
        numbers[j],numbers[j-1] = swap(numbers[j],numbers[j-1])
  return(numbers)  

def insertion_sort(numbers,cmp_fun):
  for i in range(1,len(numbers)):
    j=i
    while (j>0) and cmp_fun(numbers[j],numbers[j-1]):
      numbers[j],numbers[j-1] = swap(numbers[j],numbers[j-1])
      j=j-1
  return(numbers)

def quick_sort(numbers,cmp_fun):
  """
  stackで実装したquick sort
  """
  result = []
  stack = [numbers]
  while len(stack) != 0:
    nums = stack.pop()

    for i in range(len(nums) - 1):
      if nums[i] != nums[i + 1]:
        if cmp_fun(nums[i], nums[i + 1]):
          pivot = nums[i + 1]
        else:
          pivot = nums[i]
        
        left, right = _separate_by_pivot(nums, pivot, cmp_fun)
        stack.append(right)
        stack.append(left)
        break

    #numsが全て同じ数 or　要素数が0または1の時
    else:
      result += nums
  
  #ここでdeep copyをする
  numbers[:] = result
  return(numbers)

def _recursive_quick_sort(numbers, cmp_fun):
  """
  再帰によるクイックソートの実装(本コードでは用いない)  
  この実装だと，リストのサイズが10000以下ならば非再帰のquick sortよりも速いが,  
  それよりサイズが大きくなると非再帰のquick sortの方が速い模様である  
  (TEST_COMP_QUICK = Trueとすると実行時間の比較ができる)
  """
  
  for i in range(len(numbers) - 1):

    if numbers[i] != numbers[i + 1]:
      if cmp_fun(numbers[i], numbers[i + 1]):
        pivot = numbers[i + 1]
      else:
        pivot = numbers[i]

      left, right = _separate_by_pivot(numbers, pivot, cmp_fun)
      sorted_left = _recursive_quick_sort(left, cmp_fun)
      sorted_right = _recursive_quick_sort(right, cmp_fun)

      #deep copy
      numbers[:] = sorted_left + sorted_right
      return numbers
    
  #　numbersの値が全て同じ場合はnumbersを返すだけで良い
  return numbers

def _separate_by_pivot(numbers, pivot, cmp_fun):
  """
  numbers配列をpivotを基準に２つに分ける
  """
  left = []
  right = []

  for n in numbers:
    if cmp_fun(n, pivot):
      left.append(n)
    else:
      right.append(n)

  return (left, right)


#
## Test Harness
#

if TIME_TEST:
  size = int(input("the size of numbers (>2) "))
  numbers = [0]*size
  for i in range(0,len(numbers)):
    random.seed(None,2)
    numbers[i]=random.randint(0,size)
  start_time = time.time()
  print("{0},\n processing time(quick sort): {1} sec\n".format(quick_sort(numbers[:],comp),time.time()-start_time))
  start_time = time.time()
  print("{0},\n processing time(insertion sort): {1} sec\n".format(insertion_sort(numbers[:],comp),time.time()-start_time))
  start_time = time.time()
  print("{0},\n processing time(bubble sort): {1} sec\n".format(bubble_sort(numbers[:],comp),time.time()-start_time))
  print("oridin:\n{0}".format(numbers))


###########################
#以下は追加のテスト用コード
###########################

def test(size, time, sort_fun, cmp_fun):
  """
  sort関数のテストコード  
  sort関数の出力が正しい順に並んでいるかをテストする  
  """
  for i in range(time):
    numbers = [random.randint(0, size) for _ in range(size)]

    res = sort_fun(numbers, cmp_fun)
    for j in range(size - 1):
      if cmp_fun(res[j + 1], res[j]):
        print(j)
        print("Error")
        print(res)
        return

  print("all numbers are sorted in order")

def comp_sort_time(size, times, sort_fun1, sort_fun2, cmp):
  """
  ソート関数の実行時間を比較する
  """
  avg_dt1 = 0
  avg_dt2 = 0

  for i in range(times):
    sys.stdout.write("\r%d / 100" %(int(i * 100 / (times-1))))
    sys.stdout.flush()


    numbers = [random.randint(0, size) for _ in range(size)]
    dt1 = time_sort(numbers[:], sort_fun1, cmp)
    dt2 = time_sort(numbers[:], sort_fun2, cmp)

    avg_dt1 += dt1
    avg_dt2 += dt2
  
  avg_dt1 /= times
  avg_dt2 /= times
  print('')
  print('{} average time: {}'.format(sort_fun1.__name__, avg_dt1))
  print('{} average time: {}'.format(sort_fun2.__name__, avg_dt2))

def time_sort(numbers, sort_fun, cmp_fun):
  start_time = time.time()
  sort_fun(numbers, cmp_fun)
  end_time = time.time()

  dt = end_time - start_time   
  return dt

#テストコード
if TEST:
  print("TEST mode")
  size = int(input("the size of numbers (>2) "))
  times = int(input("the times of iterate (>1) "))
  test(size, times, quick_sort, comp)

#quicksortの再帰実装と非再帰実装の実行時間の比較
if TEST_COMP_QUICK:
  print("Compare recursive and non-recursive quick sort")
  size = int(input("the size of numbers (>2) "))
  times = int(input("the times of iterate (>1) "))
  comp_sort_time(size, times, quick_sort, _recursive_quick_sort, comp)
