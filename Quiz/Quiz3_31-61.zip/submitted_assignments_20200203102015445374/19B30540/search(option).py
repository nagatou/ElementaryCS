#################################################
# linear search　と binary search の実装と時間計測
#################################################

import os
import time
import random
import sys


def swap(x, y):
    return(y, x)


def comp(x, y):
    if (x < y):
        return(True)
    else:
        return(False)


def binary_search(numbers, key, cmp_fun):
    """
    2分探索
    配列の全て要素が順に並んでいる場合に使える．
    計算量がO(logN)となるので高速．
    検索する値がが存在した場合にはその要素の添字を返し，存在しない場合には-1を返す．
    """
    left = 0
    right = len(numbers) - 1

    # pythonはオーバーフローをしないため(left + right) / 2 としているが，
    # C言語などで実装する場合には left + right　でオーバーフローが発生する可能性があるので
    # m = left + (right - left) / 2　と実装するのが正しいらしい

    while left < right:
        m = int((left + right) / 2)

        # key < numbers[m]
        if cmp_fun(key, numbers[m]):
            right = m - 1

        # numbers[m] < key
        elif cmp_fun(numbers[m], key):
            left = m + 1

        # numbers[m] == key
        # という風に == を使わずにcmp_funだけで実装しているが
        # cmp_funを全順序関係にしてしまうとこの節に辿り付けずに無限ループに陥るので注意
        else:
            return m

    # print("{} is not founded in numbers".format(key))
    return -1


def linear_search(numbers, key, cmp_fun):
    """
    リニアサーチ
    リストの先頭から全ての要素を見て検索した値が存在するかを確かめる
    計算量はO(N)
    """
    for i, n in enumerate(numbers):
        if not (cmp_fun(key, n) or cmp_fun(n, key)):
            return i
    else:
        # print("{} is not founded in numbers".format(key))
        return -1


def timeit(search_func, numbers, key, cmp_fun):
    """
    サーチの時間を測る関数
    """
    time_start = time.time()
    search_func(numbers, key, cmp_fun)
    time_end = time.time()

    return time_end - time_start


def average_time(max_int, iter_times, cmp_fun):
    time_linear = 0
    time_binary = 0
    for _ in range(iter_times):
        numbers = [random.randint(0, max_int) for _ in range(max_int)]
        quick_sort(numbers, cmp_fun)
        key = random.randint(0, max_int)
        time_linear += timeit(linear_search, numbers, key, cmp_fun)
        time_binary += timeit(binary_search, numbers, key, cmp_fun)
    time_linear /= iter_times
    time_binary /= iter_times

    print("{} average time : {:e}".format(linear_search.__name__, time_linear))
    print("{} average time : {:e}".format(binary_search.__name__, time_binary))


def quick_sort(numbers, cmp_fun):
    i = 0
    stack = [numbers]
    result = []
    while len(stack) > 0:
        nums = stack.pop()
        for i in range(len(nums) - 1):
            if nums[i] == nums[i + 1]:
                continue

            if cmp_fun(nums[i], nums[i + 1]):
                pivot = nums[i + 1]
            else:
                pivot = nums[i]

            left, right = _divite_list_by_pivot(nums, pivot, cmp_fun)
            stack.append(right)
            stack.append(left)
            break
        else:
            result += nums

    numbers[:] = result
    return numbers


def _divite_list_by_pivot(numbers, pivot, cmp_fun):
    left = []
    right = []
    for n in numbers:
        # n < pivot
        if cmp_fun(n, pivot):
            left.append(n)
        else:
            right.append(n)

    return (left, right)


######################################################################
N = int(input("length of list : "))
M = int(input("times of iterate : "))
average_time(N, M, comp)
"""
#簡単にsearchの結果を表示する
N = 100
numbers = [random.randint(0, N) for i in range(N)]
key = random.randint(0, N)
quick_sort(numbers, comp)

print(key)
print(numbers)
ind = binary_search(numbers, key, comp)
print(ind)
if ind != -1:
    print(numbers[ind])
"""
