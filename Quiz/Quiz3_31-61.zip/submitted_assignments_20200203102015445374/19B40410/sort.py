##19B40410
# Several sorting algorithms
#Mode:: Python3

import os, time, random

def swap (x,y):
  return(y,x)
def comp (x,y):
  if (x < y):
    return(True)
  else:
    return(False)

def bubble_sort(numbers,cmp_fun):
  for i in range(0,len(numbers)):
    for j in range(len(numbers)-1,i,-1):
      if cmp_fun(numbers[j],numbers[j-1]):
        numbers[j],numbers[j-1] = swap(numbers[j],numbers[j-1])
  return(numbers)  

def insertion_sort(numbers,cmp_fun):
  for i in range(1,len(numbers)):
    j=i
    while (j>0) and cmp_fun(numbers[j],numbers[j-1]):
      numbers[j],numbers[j-1] = swap(numbers[j],numbers[j-1])
      j=j-1
  return(numbers)

def quick_sort(numbers,cmp_fun):
  if (len(set(numbers)) > 1):                  #配列に異なる値があるとき
    for i in range(0,len(numbers)):
      if (numbers[i] != numbers[i+1]):         #左から異なる値が出るまで探していき
        pivot = max(numbers[i],numbers[i+1])   #その内大きいほうをpivotとする
        break
    left = [i for i in numbers if i<pivot]     #pivotより小さい値を左に
    right = [i for i in numbers if i>=pivot]   #pivotより大きい値を右に集める
    numbers = quick_sort(left,cmp_fun) + quick_sort(right,cmp_fun)  #再起
  return(numbers)

#
## Test Harness
#
size = int(input("the size of numbers (>2) "))
numbers = [0]*size
for i in range(0,len(numbers)):
  random.seed(None,2)
  numbers[i]=random.randint(0,size)
start_time = time.time()
print("{0},\n processing time(quick sort): {1} sec\n".format(quick_sort(numbers[:],comp),time.time()-start_time))
start_time = time.time()
print("{0},\n processing time(insertion sort): {1} sec\n".format(insertion_sort(numbers[:],comp),time.time()-start_time))
start_time = time.time()
print("{0},\n processing time(bubble sort): {1} sec\n".format(bubble_sort(numbers[:],comp),time.time()-start_time))
print("oridin:\n{0}".format(numbers))
