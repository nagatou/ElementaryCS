# Several sorting algorithms
#Mode:: Python3
# optional homework
#quick sortのオーダーは
#最悪計算量：pivotとの比較回数が(n-1)+(n-2)+...+2+1=1/2n(n-1)となる時なので、O(n^2)
#平均計算量：入力のリストのn!通りの並び方がすべて等確率であるとする。quick sortの計算量をQ(n)とすると、pivotがi番目にあるとき、以下の漸化式を満たす。
#Q(n)<=Q(i-1)+Q(n-i)+c*(n-1)  (ただしcはpivotとの比較にかかる計算量)
#pivotの現れる位置はすべて等確率であるとしているので平均計算量は
#Q(n)<=(1/n)*[{Q(i-1)+Q(n-i)+c*(n-1)}のi=1~nの総和]
#これを計算して、Q(n) = O(nlogn)

import os, time, random

def swap (x,y):
  return(y,x)
def comp (x,y):
  if (x < y):
    return(True)
  else:
    return(False)

def bubble_sort(numbers,cmp_fun):
  for i in range(0,len(numbers)):
    for j in range(len(numbers)-1,i,-1):
      if cmp_fun(numbers[j],numbers[j-1]):
        numbers[j],numbers[j-1] = swap(numbers[j],numbers[j-1])
  return(numbers)  

def insertion_sort(numbers,cmp_fun):
  for i in range(1,len(numbers)):
    j=i
    while (j>0) and cmp_fun(numbers[j],numbers[j-1]):
      numbers[j],numbers[j-1] = swap(numbers[j],numbers[j-1])
      j=j-1
  return(numbers)

def quick_sort(numbers,cmp_fun):
  left = []
  right = []
  if len(numbers) <= 1:
    return(numbers)

  pivot = max(numbers[0], numbers[1])
  pivot_count = 0

  for num in numbers:
    if num < pivot:
      left.append(num)
    elif num > pivot:
      right.append(num)
    else:
      pivot_count += 1
  left = quick_sort(left,cmp_fun)
  right = quick_sort(right,cmp_fun)
  
  return(left + [pivot] * pivot_count + right)

#
## Test Harness
#
size = int(input("the size of numbers (>2) "))
numbers = [0]*size
for i in range(0,len(numbers)):
  random.seed(None,2)
  numbers[i]=random.randint(0,size)
start_time = time.time()
print("{0},\n processing time(quick sort): {1} sec\n".format(quick_sort(numbers[:],comp),time.time()-start_time))
start_time = time.time()
print("{0},\n processing time(insertion sort): {1} sec\n".format(insertion_sort(numbers[:],comp),time.time()-start_time))
start_time = time.time()
print("{0},\n processing time(bubble sort): {1} sec\n".format(bubble_sort(numbers[:],comp),time.time()-start_time))
print("oridin:\n{0}".format(numbers))
