# Several sorting algorithms
#Mode:: Python3

import os, time, random, sys
sys.setrecursionlimit(2000)

def swap (x,y):
  return(y,x)
def comp (x,y):
  if (x < y):
    return(True)
  else:
    return(False)

def bubble_sort(numbers,cmp_fun):
  for i in range(0,len(numbers)):
    for j in range(len(numbers)-1,i,-1):
      if cmp_fun(numbers[j],numbers[j-1]):
        numbers[j],numbers[j-1] = swap(numbers[j],numbers[j-1])
  return(numbers)  

def insertion_sort(numbers,cmp_fun):
  for i in range(1,len(numbers)):
    j=i
    while (j>0) and cmp_fun(numbers[j],numbers[j-1]):
      numbers[j],numbers[j-1] = swap(numbers[j],numbers[j-1])
      j=j-1
  return(numbers)

def quick_sort(numbers,cmp_fun):
  ### ?????
  # rand = random.randint(0, len(numbers)-1)
  # pivot = numbers[rand]
  pivot = random.choice(numbers)
  left = []
  right = []
  for i in range(len(numbers)):
    if cmp_fun(numbers[i], pivot):
      left.append(numbers[i])
    else:
      right.append(numbers[i])
  if len(list(set(right))) > 1:
    right = quick_sort(right, cmp_fun)
  if len(list(set(left))) > 1:
    left = quick_sort(left, cmp_fun)
  # numbers = sum([left, right], [])
  numbers = left + right
  return(numbers)

def quick_sort_2(numbers, cmp_fun):
  left = []
  right = []
  if len(numbers) <= 1:
    return numbers
  pivot = random.choice(numbers)
  pivot_count = 0
  for num in numbers:
    if cmp_fun(num, pivot):
      left.append(num)
    elif not (cmp_fun(num, pivot)) and num != pivot:
      right.append(num)
    else:
      pivot_count += 1
  left = quick_sort_2(left, cmp_fun)
  right = quick_sort_2(right,cmp_fun)
  return left + [pivot]*pivot_count + right

def sellect_sort(numbers):   # これもまあまあ早い
  for i, num in enumerate(numbers):
    min_i = min(range(i, len(numbers)), key = numbers.__getitem__)
    numbers[i], numbers[min_i] = numbers[min_i], num
  return numbers

def count_sort(numbers):
  max_num = max(numbers)
  min_num = min(numbers)
  count = [0] * (max_num - min_num + 1)
  for num in numbers:
    count[num - min_num] += 1
  return [ele for ele, cnt in enumerate(count, start=min_num) for __ in range(cnt)]

# ネットで見つけた中で一番早いもの　めちゃめちゃはやい
def quick_sort_with_count(arr):    
    left = []
    right = []
    if len(arr) <= 1:
        return arr
    ref = random.choice(arr)
    ref_count = 0

    for ele in arr:
      if ele < ref:
        left.append(ele)
      elif ele > ref:
        right.append(ele)
      else:
        ref_count += 1

    if len(left) <= 1000:
      left = count_sort(left)
    else:
      left = quick_sort_with_count(left)
    if len(right) <= 1000:
      right = count_sort(right)
    else:
      right = quick_sort_with_count(right)

    return left + [ref] * ref_count + right


#
## Test Harness
#
size = int(input("the size of numbers (>2) "))
numbers = [0]*size
for i in range(0,len(numbers)):
  random.seed(None,2)
  numbers[i]=random.randint(0,size)
start_time = time.time()
print("{0},\n processing time(quick sort): {1} sec\n".format(quick_sort(numbers[:],comp),time.time()-start_time))
start_time = time.time()
print("{0},\n processing time(quick sort 2): {1} sec\n".format(quick_sort_2(numbers[:],comp),time.time()-start_time))
start_time = time.time()
print("{0},\n processing time(sellect sort): {1} sec\n".format(sellect_sort(numbers[:]),time.time()-start_time))
start_time = time.time()
print("{0},\n processing time(count sort): {1} sec\n".format(count_sort(numbers[:]),time.time()-start_time))
start_time = time.time()
print("{0},\n processing time(quick sort with count): {1} sec\n".format(quick_sort_with_count(numbers[:]),time.time()-start_time))
start_time = time.time()
print("{0},\n processing time(insertion sort): {1} sec\n".format(insertion_sort(numbers[:],comp),time.time()-start_time))
start_time = time.time()
print("{0},\n processing time(bubble sort): {1} sec\n".format(bubble_sort(numbers[:],comp),time.time()-start_time))
print("oridin:\n{0}".format(numbers))
