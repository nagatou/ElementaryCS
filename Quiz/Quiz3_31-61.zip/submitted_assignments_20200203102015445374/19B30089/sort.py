# sort.py
# Several sorting algorithms
# Mode:: Python3

## order:
#
# Bubble_sort : O(n^2)
# Insertion_sort : O(n^2)
# quick_sort : O(n*log(n))

import os, time, random

def swap (x,y):
    return(y,x)

def comp (x,y):
    if (x < y):
        return(True)
    else:
        return(False)

def bubble_sort(numbers,cmp_fun):
    for i in range(0,len(numbers)):
        for j in range(len(numbers)-1,i,-1):
            if cmp_fun(numbers[j],numbers[j-1]):
                numbers[j],numbers[j-1] = swap(numbers[j],numbers[j-1])
    return(numbers)  

def insertion_sort(numbers,cmp_fun):
    for i in range(1,len(numbers)):
        j=i
        while (j>0) and cmp_fun(numbers[j],numbers[j-1]):
            numbers[j],numbers[j-1] = swap(numbers[j],numbers[j-1])
            j=j-1
    return(numbers)

def piv(numbers):  # pivotを求める関数
    if len(numbers) <= 6:  # 長さが6以下のときは最初の要素を取得
        return(numbers[0])
    else:  # 長さが7以上のときは最初の3つの要素の中央値を取得
        lst = [numbers[0], numbers[1], numbers[2]]
        max = 0
        for i in range(1, 3):
            if lst[i] > max:
                max = i
        del lst[max]
        if lst[0] < lst[1]:
            return(lst[0])
        else:
            return(lst[1])

def quick_sort(numbers, cmp_fun):  # 課題
    if len(numbers) == 0:  # 再帰終了を定義
        return[]
    elif len(numbers) == 1:  # 再帰終了を定義
        return([numbers[0]])
    else:
        left, right = [], []
        count = 0
        pivot = piv(numbers)
        for i in range(len(numbers)):
            if comp(numbers[i], pivot):  # pivotよりも小きい[大さい]とき
                left.append(numbers[i])
            elif numbers[i] == pivot:  # pivotと等しいとき
                count += 1
            else:  # pivotよりも大さい[小きい]とき
                right.append(numbers[i])
        return(quick_sort(left, cmp_fun) + [pivot]*count + quick_sort(right, cmp_fun))

#
## Test Harness
#
size = int(input("the size of numbers (>2) "))
numbers = [0]*size
for i in range(0,len(numbers)):
    random.seed(None,2)
    numbers[i]=random.randint(0,size)
start_time = time.time()
print("{0},\n processing time(quick sort): {1} sec\n".format(quick_sort(numbers[:],comp),time.time()-start_time))
start_time = time.time()
print("{0},\n processing time(insertion sort): {1} sec\n".format(insertion_sort(numbers[:],comp),time.time()-start_time))
start_time = time.time()
print("{0},\n processing time(bubble sort): {1} sec\n".format(bubble_sort(numbers[:],comp),time.time()-start_time))
print("oridin:\n{0}".format(numbers))
