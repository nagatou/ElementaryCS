# search.py

#
## 動作説明
#
# 最初に、順番通りに並んだ、重複を含む配列を生成する。(sort.pyの乱数生成とquick_sortを
# 組み合わせている)。探したい番号を、linear_searchとbinary_searchを用いて探し、実行時
# 間を計測する。重複を含んでいても探すことができるようになっている。また、存在しない要
# 素を検索した場合はNoneが返されるようになっている。プレイヤーは最初の配列の長さと、探
# す番号の2つを入力する。
# comp中の不等号入れ替えに対応。序数の表現も正確に(1th → 1st, 2th → 2nd)プログラム

## order:
#
# linear serch : O(n)
# bynary serch : O(log(n))

import os, time, random, sys

def comp (x,y):  # sort.pyから引用、配列を求めるために使用する
    if (x < y):
        return(True)
    else:
        return(False)

def piv(numbers):
    if len(numbers) <= 6:
        return(numbers[0])
    else:
        lst = [numbers[0], numbers[1], numbers[2]]
        max = 0
        for i in range(1, 3):
            if lst[i] > max:
                max = i
        del lst[max]
        if lst[0] < lst[1]:
            return(lst[0])
        else:
            return(lst[1])

def quick_sort(numbers, cmp_fun):
    if len(numbers) == 0:
        return[]
    elif len(numbers) == 1:
        return([numbers[0]])
    else:
        left, right = [], []
        count = 0
        pivot = piv(numbers)
        for i in range(len(numbers)):
            if comp(numbers[i], pivot):
                left.append(numbers[i])
            elif numbers[i] == pivot:
                count += 1
            else:
                right.append(numbers[i])
        return(quick_sort(left, cmp_fun) + [pivot]*count + quick_sort(right, cmp_fun))

def linear_search(numbers, a):  # 課題1 : linear search
    place = []
    stop = False
    for i in range(len(numbers)):
        if numbers[i] == a:
            place.append(i)
            stop = True
        elif comp(a, numbers[i]) and stop:  # 見つかり次第ループを止める
            break
    return(place)  # 位置をリストで返す

def binary_search(numbers, a, p):  # 課題2 : binary_search  , pは開始点
    if numbers == []:
        return[]
    pivot = int(len(numbers) / 2)
    if numbers[pivot] == a:
        start, end, point = pivot+p, pivot+p+1, pivot+p
        for i in range(pivot):
            if numbers[pivot-i-1] == a:
                start -= 1
        for i in range(len(numbers)-pivot-1):
            if numbers[pivot+i+1] == a:
                end += 1
        return(list(range(start, end)))
        #return[point]
    elif comp(numbers[pivot], a):
        p += pivot+1
        del numbers[:pivot+1]
        return(binary_search(numbers, a, p))
    else:
        del numbers[pivot:]
        return(binary_search(numbers, a, p))

def exp_num(x):  # 数字の表現
    if x == 1:
        return("1st")
    elif x == 2:
        return("2nd")
    elif x == 3:
        return("3rd")
    else:
        return(f"{x}th")

def exp_plc(y):  # 場所の表現
    if y == []:
        return("None")
    elif len(y) == 1:
        return(f"in the {exp_num(y[0])}")
    else:
        d = ""
        for i in range(len(y) - 1):
            d += f"{exp_num(y[i])}, " 
        return("in the " + d + "and " + exp_num(y[len(y) - 1]))
        
#
## Test Harness
#

# 配列の生成
nl = int(input("numbers length? (>2)"))
numbers = [0]*nl
for i in range(0,len(numbers)):
    random.seed(None,2)
    numbers[i]=random.randint(0,nl)
numbers = quick_sort(numbers, comp)
print("numbers:\n{}".format(numbers))

sn = int(input("search number (0~{})?".format(nl)))

start_time = time.time()
print(f"{sn} is {exp_plc(linear_search(numbers, sn))}.  \n processing time(linear search): {time.time() - start_time} sec. \n")
start_time = time.time()
print(f"{sn} is {exp_plc(binary_search(numbers, sn, 0))}.  \n processing time(binary search): {time.time() - start_time} sec. \n")
